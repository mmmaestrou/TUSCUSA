import { Router, type IRouter } from "express";
import healthRouter from "./health";
import membersRouter from "./members";
import fundingRouter from "./funding";
import suggestionsRouter from "./suggestions";
import votesRouter from "./votes";
import reportsRouter from "./reports";
import eventsRouter from "./events";
import talentsRouter from "./talents";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(membersRouter);
router.use(fundingRouter);
router.use(suggestionsRouter);
router.use(votesRouter);
router.use(reportsRouter);
router.use(eventsRouter);
router.use(talentsRouter);
router.use(dashboardRouter);

export default router;
