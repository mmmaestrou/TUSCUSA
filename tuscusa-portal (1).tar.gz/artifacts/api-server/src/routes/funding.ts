import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, fundingTable } from "@workspace/db";
import {
  CreateFundingBody,
  UpdateFundingBody,
  GetFundingParams,
  UpdateFundingParams,
  DeleteFundingParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/funding/summary", async (req, res): Promise<void> => {
  const rows = await db.select().from(fundingTable);
  let totalApplied = 0;
  let totalReceived = 0;
  const byStatus: Record<string, number> = {};
  const byPurpose: Record<string, number> = {};

  for (const row of rows) {
    totalApplied += row.amountApplied;
    if (row.amountReceived) totalReceived += row.amountReceived;
    byStatus[row.status] = (byStatus[row.status] ?? 0) + 1;
    byPurpose[row.purpose] = (byPurpose[row.purpose] ?? 0) + 1;
  }

  res.json({ totalApplied, totalReceived, byStatus, byPurpose });
});

router.get("/funding", async (req, res): Promise<void> => {
  const records = await db.select().from(fundingTable).orderBy(fundingTable.createdAt);
  res.json(records);
});

router.post("/funding", async (req, res): Promise<void> => {
  const parsed = CreateFundingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.insert(fundingTable).values(parsed.data).returning();
  res.status(201).json(record);
});

router.get("/funding/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const [record] = await db.select().from(fundingTable).where(eq(fundingTable.id, id));
  if (!record) {
    res.status(404).json({ error: "Funding record not found" });
    return;
  }
  res.json(record);
});

router.patch("/funding/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const parsed = UpdateFundingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(parsed.data)) {
    if (v !== null && v !== undefined) updateData[k] = v;
  }

  const [record] = await db.update(fundingTable).set(updateData).where(eq(fundingTable.id, id)).returning();
  if (!record) {
    res.status(404).json({ error: "Funding record not found" });
    return;
  }
  res.json(record);
});

router.delete("/funding/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const [record] = await db.delete(fundingTable).where(eq(fundingTable.id, id)).returning();
  if (!record) {
    res.status(404).json({ error: "Funding record not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
