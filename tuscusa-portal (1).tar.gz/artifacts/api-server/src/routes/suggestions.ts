import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, suggestionsTable } from "@workspace/db";
import {
  CreateSuggestionBody,
  UpdateSuggestionBody,
  GetSuggestionParams,
  UpdateSuggestionParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/suggestions", async (req, res): Promise<void> => {
  const suggestions = await db.select().from(suggestionsTable).orderBy(suggestionsTable.createdAt);
  res.json(suggestions);
});

router.post("/suggestions", async (req, res): Promise<void> => {
  const parsed = CreateSuggestionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const data = {
    ...parsed.data,
    isAnonymous: parsed.data.isAnonymous ?? false,
  };
  const [suggestion] = await db.insert(suggestionsTable).values(data).returning();
  res.status(201).json(suggestion);
});

router.get("/suggestions/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const [suggestion] = await db.select().from(suggestionsTable).where(eq(suggestionsTable.id, id));
  if (!suggestion) {
    res.status(404).json({ error: "Suggestion not found" });
    return;
  }
  res.json(suggestion);
});

router.patch("/suggestions/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const parsed = UpdateSuggestionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = {};
  if (parsed.data.status) updateData.status = parsed.data.status;
  if (parsed.data.executiveResponse != null) {
    updateData.executiveResponse = parsed.data.executiveResponse;
    updateData.respondedAt = new Date();
  }

  const [suggestion] = await db.update(suggestionsTable).set(updateData).where(eq(suggestionsTable.id, id)).returning();
  if (!suggestion) {
    res.status(404).json({ error: "Suggestion not found" });
    return;
  }
  res.json(suggestion);
});

export default router;
