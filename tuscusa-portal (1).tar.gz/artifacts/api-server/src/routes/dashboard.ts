import { Router, type IRouter } from "express";
import { gte } from "drizzle-orm";
import { db, membersTable, fundingTable, suggestionsTable, votesTable, reportsTable, eventsTable, talentsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  const [members, funding, suggestions, votes, reports, events, talents] = await Promise.all([
    db.select().from(membersTable),
    db.select().from(fundingTable),
    db.select().from(suggestionsTable),
    db.select().from(votesTable),
    db.select().from(reportsTable),
    db.select().from(eventsTable),
    db.select().from(talentsTable),
  ]);

  const totalFunding = funding.reduce((sum, f) => sum + (f.amountReceived ?? 0), 0);
  const pendingSuggestions = suggestions.filter(s => s.status === "pending" || s.status === "under_review").length;
  const activeVotes = votes.filter(v => v.status === "open").length;
  const upcomingEvents = events.filter(e => e.isActive && (e.eventDate ? new Date(e.eventDate) > new Date() : true)).length;
  const verifiedMembers = members.filter(m => m.isVerified).length;

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const recentReports = reports.filter(r => new Date(r.createdAt) > thirtyDaysAgo).length;

  res.json({
    totalMembers: members.length,
    verifiedMembers,
    pendingSuggestions,
    activeVotes,
    totalFunding,
    upcomingEvents,
    totalTalents: talents.length,
    recentReports,
  });
});

router.get("/dashboard/recent-activity", async (req, res): Promise<void> => {
  const [members, suggestions, votes, reports, events, talents] = await Promise.all([
    db.select().from(membersTable),
    db.select().from(suggestionsTable),
    db.select().from(votesTable),
    db.select().from(reportsTable),
    db.select().from(eventsTable),
    db.select().from(talentsTable),
  ]);

  const activity: Array<{ id: string; type: string; description: string; timestamp: Date; status: string | null }> = [];

  for (const m of members.slice(-5)) {
    activity.push({
      id: `member-${m.id}`,
      type: "member",
      description: `${m.fullName} registered as a ${m.employmentStatus.replace("_", " ")} youth member`,
      timestamp: m.createdAt,
      status: m.isVerified ? "verified" : "pending",
    });
  }

  for (const s of suggestions.slice(-5)) {
    activity.push({
      id: `suggestion-${s.id}`,
      type: "suggestion",
      description: `New suggestion: "${s.title}"`,
      timestamp: s.createdAt,
      status: s.status,
    });
  }

  for (const v of votes.slice(-3)) {
    activity.push({
      id: `vote-${v.id}`,
      type: "vote",
      description: `Policy vote opened: "${v.title}"`,
      timestamp: v.createdAt,
      status: v.status,
    });
  }

  for (const r of reports.slice(-3)) {
    activity.push({
      id: `report-${r.id}`,
      type: "report",
      description: `Executive report published: "${r.title}"`,
      timestamp: r.createdAt,
      status: r.type,
    });
  }

  for (const e of events.slice(-3)) {
    activity.push({
      id: `event-${e.id}`,
      type: "event",
      description: `New ${e.type.replace("_", " ")}: "${e.title}"`,
      timestamp: e.createdAt,
      status: e.isActive ? "active" : "inactive",
    });
  }

  activity.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  res.json(activity.slice(0, 20));
});

export default router;
