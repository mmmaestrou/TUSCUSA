import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, votesTable } from "@workspace/db";
import {
  CreateVoteBody,
  GetVoteParams,
  CastVoteBody,
  CastVoteParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/votes", async (req, res): Promise<void> => {
  const votes = await db.select().from(votesTable).orderBy(votesTable.createdAt);
  res.json(votes);
});

router.post("/votes", async (req, res): Promise<void> => {
  const parsed = CreateVoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [vote] = await db.insert(votesTable).values({
    ...parsed.data,
    status: "open",
  }).returning();
  res.status(201).json(vote);
});

router.get("/votes/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const [vote] = await db.select().from(votesTable).where(eq(votesTable.id, id));
  if (!vote) {
    res.status(404).json({ error: "Vote not found" });
    return;
  }
  res.json(vote);
});

router.post("/votes/:id/cast", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const parsed = CastVoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db.select().from(votesTable).where(eq(votesTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Vote not found" });
    return;
  }
  if (existing.status === "closed") {
    res.status(400).json({ error: "Voting is closed" });
    return;
  }

  const choice = parsed.data.choice;
  const updateData: Record<string, unknown> = {
    totalVoters: sql`${votesTable.totalVoters} + 1`,
  };

  if (choice === "yes") updateData.yesCount = sql`${votesTable.yesCount} + 1`;
  else if (choice === "no") updateData.noCount = sql`${votesTable.noCount} + 1`;
  else updateData.abstainCount = sql`${votesTable.abstainCount} + 1`;

  const [vote] = await db.update(votesTable).set(updateData).where(eq(votesTable.id, id)).returning();
  res.json(vote);
});

export default router;
