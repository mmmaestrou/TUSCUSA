import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, talentsTable } from "@workspace/db";
import {
  CreateTalentBody,
  GetTalentParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/talents", async (req, res): Promise<void> => {
  const talents = await db.select().from(talentsTable).orderBy(talentsTable.createdAt);
  res.json(talents);
});

router.post("/talents", async (req, res): Promise<void> => {
  const parsed = CreateTalentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [talent] = await db.insert(talentsTable).values(parsed.data).returning();
  res.status(201).json(talent);
});

router.get("/talents/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const [talent] = await db.select().from(talentsTable).where(eq(talentsTable.id, id));
  if (!talent) {
    res.status(404).json({ error: "Talent not found" });
    return;
  }
  res.json(talent);
});

export default router;
