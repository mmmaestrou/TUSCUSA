import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Dashboard from "@/pages/dashboard";
import Members from "@/pages/members";
import FundingTracker from "@/pages/funding";
import Suggestions from "@/pages/suggestions";
import Votes from "@/pages/votes";
import Reports from "@/pages/reports";
import Events from "@/pages/events";
import Talents from "@/pages/talents";
import AdminPanel from "@/pages/admin";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/members" component={Members} />
      <Route path="/funding" component={FundingTracker} />
      <Route path="/suggestions" component={Suggestions} />
      <Route path="/votes" component={Votes} />
      <Route path="/reports" component={Reports} />
      <Route path="/events" component={Events} />
      <Route path="/talents" component={Talents} />
      <Route path="/admin" component={AdminPanel} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;