import { useListReports, useGetReport } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { FileText, FileBarChart, Users, Gavel, Calendar, Download, Eye } from "lucide-react";
import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function Reports() {
  const { data: reports, isLoading } = useListReports();
  const [selectedReportId, setSelectedReportId] = useState<number | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  
  const { data: fullReport, isLoading: isLoadingReport } = useGetReport(selectedReportId || 0, {
    query: {
      enabled: selectedReportId !== null && isViewerOpen,
      queryKey: ["/api/reports", selectedReportId]
    }
  });

  const getReportIcon = (type: string) => {
    switch (type) {
      case "financial": return <FileBarChart className="h-5 w-5 text-green-600" />;
      case "minutes": return <Users className="h-5 w-5 text-blue-600" />;
      case "decision": return <Gavel className="h-5 w-5 text-orange-600" />;
      default: return <FileText className="h-5 w-5 text-slate-600" />;
    }
  };

  const getReportTypeLabel = (type: string) => {
    switch (type) {
      case "financial": return "Financial Report";
      case "minutes": return "Meeting Minutes";
      case "decision": return "Executive Decision";
      default: return "General Document";
    }
  };

  const openReport = (id: number) => {
    setSelectedReportId(id);
    setIsViewerOpen(true);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Official Reports</h1>
          <p className="text-muted-foreground">Access meeting minutes, financial disclosures, and executive decisions.</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Skeleton className="h-12 w-12 rounded-lg" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-5 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                      <Skeleton className="h-4 w-1/3 mt-4" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : reports?.length === 0 ? (
            <div className="col-span-full py-16 flex flex-col items-center justify-center text-center border rounded-xl border-dashed bg-card/50">
              <FileText className="h-12 w-12 text-muted-foreground opacity-20 mb-4" />
              <h3 className="text-xl font-medium">No reports published</h3>
              <p className="text-muted-foreground mt-1">Check back later for official documentation.</p>
            </div>
          ) : (
            reports?.map((report) => (
              <Card key={report.id} className="hover-elevate cursor-pointer transition-colors" onClick={() => openReport(report.id)}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center shrink-0">
                      {getReportIcon(report.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-lg truncate" title={report.title}>{report.title}</h3>
                      <div className="flex flex-wrap items-center gap-2 mt-1 mb-3">
                        <Badge variant="secondary" className="text-xs font-normal">
                          {getReportTypeLabel(report.type)}
                        </Badge>
                        {report.period && (
                          <span className="text-xs text-muted-foreground flex items-center">
                            <Calendar className="h-3 w-3 mr-1" /> {report.period}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between text-sm text-muted-foreground border-t pt-3">
                        <span className="truncate pr-2">By {report.publishedBy}</span>
                        <span className="shrink-0">{new Date(report.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      <Dialog open={isViewerOpen} onOpenChange={setIsViewerOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[85vh] flex flex-col p-0 overflow-hidden">
          {isLoadingReport || !fullReport ? (
            <div className="p-6 space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-4 w-1/4 mb-8" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-4/5" />
              </div>
            </div>
          ) : (
            <>
              <div className="px-6 py-4 border-b bg-muted/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded bg-background border shadow-sm flex items-center justify-center shrink-0">
                      {getReportIcon(fullReport.type)}
                    </div>
                    <div>
                      <DialogTitle className="text-xl">{fullReport.title}</DialogTitle>
                      <DialogDescription className="flex items-center gap-2 mt-1">
                        <span className="font-medium text-foreground">{getReportTypeLabel(fullReport.type)}</span>
                        <span>•</span>
                        <span>Published {new Date(fullReport.createdAt).toLocaleDateString()}</span>
                      </DialogDescription>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="hidden sm:flex">
                    <Download className="h-4 w-4 mr-2" /> Download
                  </Button>
                </div>
              </div>
              <ScrollArea className="flex-1 p-6">
                <div className="prose prose-slate dark:prose-invert max-w-none prose-h3:mt-0">
                  <div className="mb-8 p-4 bg-muted/30 rounded-lg border text-sm">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Published By:</div>
                      <div className="font-medium">{fullReport.publishedBy}</div>
                      
                      {fullReport.period && (
                        <>
                          <div className="text-muted-foreground">Reporting Period:</div>
                          <div className="font-medium">{fullReport.period}</div>
                        </>
                      )}
                      
                      <div className="text-muted-foreground">Document ID:</div>
                      <div className="font-mono text-xs">DOC-{fullReport.id.toString().padStart(6, '0')}</div>
                    </div>
                  </div>
                  
                  <div className="whitespace-pre-wrap leading-relaxed">
                    {fullReport.content}
                  </div>
                </div>
              </ScrollArea>
              <div className="px-6 py-4 border-t bg-muted/10 sm:hidden">
                <Button className="w-full">
                  <Download className="h-4 w-4 mr-2" /> Download PDF
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}