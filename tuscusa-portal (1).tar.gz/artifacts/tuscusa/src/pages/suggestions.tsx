import { useListSuggestions, useCreateSuggestion } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { MessageSquare, Plus, CheckCircle2, Clock, Activity, ThumbsUp, HelpCircle } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function Suggestions() {
  const { data: suggestions, isLoading } = useListSuggestions();
  const createSuggestion = useCreateSuggestion();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [submittedBy, setSubmittedBy] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending": return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" /> Pending</Badge>;
      case "under_review": return <Badge variant="outline" className="border-blue-500 text-blue-600 bg-blue-50 dark:bg-blue-950 dark:text-blue-400"><Activity className="h-3 w-3 mr-1" /> Under Review</Badge>;
      case "accepted": return <Badge variant="outline" className="border-green-500 text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400"><ThumbsUp className="h-3 w-3 mr-1" /> Accepted</Badge>;
      case "implemented": return <Badge className="bg-green-600 hover:bg-green-700"><CheckCircle2 className="h-3 w-3 mr-1" /> Implemented</Badge>;
      case "rejected": return <Badge variant="destructive">Rejected</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createSuggestion.mutate({
      data: {
        title,
        content,
        submittedBy: isAnonymous ? undefined : submittedBy,
        isAnonymous
      }
    }, {
      onSuccess: () => {
        toast({ title: "Suggestion submitted successfully", description: "Thank you for your feedback." });
        setOpen(false);
        setTitle("");
        setContent("");
        setSubmittedBy("");
        setIsAnonymous(false);
        queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      },
      onError: () => {
        toast({ title: "Error submitting suggestion", description: "Please try again later.", variant: "destructive" });
      }
    });
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Suggestion Portal</h1>
            <p className="text-muted-foreground">Voice your ideas, concerns, and feedback to the executive team.</p>
          </div>
          
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" /> New Suggestion</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>Submit a Suggestion</DialogTitle>
                  <DialogDescription>
                    Your feedback helps improve our ward. You can submit this anonymously if you prefer.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="title">Title</Label>
                    <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Brief summary of your idea" required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="content">Details</Label>
                    <Textarea id="content" value={content} onChange={(e) => setContent(e.target.value)} placeholder="Provide full details here..." className="min-h-[120px]" required />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-md">
                    <div className="space-y-0.5">
                      <Label htmlFor="anonymous">Submit Anonymously</Label>
                      <p className="text-xs text-muted-foreground">Hide your identity from the public</p>
                    </div>
                    <Switch id="anonymous" checked={isAnonymous} onCheckedChange={setIsAnonymous} />
                  </div>
                  {!isAnonymous && (
                    <div className="grid gap-2">
                      <Label htmlFor="name">Your Name (Optional)</Label>
                      <Input id="name" value={submittedBy} onChange={(e) => setSubmittedBy(e.target.value)} placeholder="John Doe" />
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={createSuggestion.isPending}>
                    {createSuggestion.isPending ? "Submitting..." : "Submit Suggestion"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="h-full">
                <CardHeader className="pb-2">
                  <Skeleton className="h-5 w-20 mb-2" />
                  <Skeleton className="h-6 w-full" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
                <CardFooter>
                  <Skeleton className="h-4 w-32" />
                </CardFooter>
              </Card>
            ))
          ) : suggestions?.length === 0 ? (
            <div className="col-span-full py-12 flex flex-col items-center justify-center text-center border rounded-xl border-dashed bg-card/50">
              <MessageSquare className="h-10 w-10 text-muted-foreground opacity-20 mb-4" />
              <h3 className="text-lg font-medium">No suggestions yet</h3>
              <p className="text-muted-foreground max-w-sm mt-1">Be the first to share an idea for the ward. Your voice matters.</p>
              <Button variant="outline" className="mt-4" onClick={() => setOpen(true)}>Submit a Suggestion</Button>
            </div>
          ) : (
            suggestions?.map((suggestion) => (
              <Card key={suggestion.id} className="flex flex-col h-full hover-elevate transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start mb-2">
                    {getStatusBadge(suggestion.status)}
                    <span className="text-xs text-muted-foreground">
                      {new Date(suggestion.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <CardTitle className="text-lg leading-tight">{suggestion.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground line-clamp-4">
                    {suggestion.content}
                  </p>
                  
                  {suggestion.executiveResponse && (
                    <div className="mt-4 p-3 bg-primary/5 rounded-md border border-primary/10">
                      <div className="flex items-center gap-2 mb-1">
                        <ShieldCheck className="h-3.5 w-3.5 text-primary" />
                        <span className="text-xs font-semibold text-primary">Executive Response</span>
                      </div>
                      <p className="text-xs text-foreground leading-relaxed line-clamp-3">
                        {suggestion.executiveResponse}
                      </p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="pt-3 border-t bg-muted/20">
                  <div className="text-xs text-muted-foreground font-medium">
                    By: {suggestion.isAnonymous ? "Anonymous Member" : (suggestion.submittedBy || "Unknown Member")}
                  </div>
                </CardFooter>
              </Card>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}

function ShieldCheck(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}