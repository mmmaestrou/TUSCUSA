import { useGetDashboardSummary, useGetRecentActivity } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileText, Vote, MessageSquare, Calendar, Star, TrendingUp, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: summary, isLoading: isLoadingSummary } = useGetDashboardSummary();
  const { data: activity, isLoading: isLoadingActivity } = useGetRecentActivity();

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Command Centre</h1>
          <p className="text-muted-foreground mt-1">Real-time overview of TUSCUSA's civic operations.</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Members"
            value={summary?.totalMembers}
            description={`${summary?.verifiedMembers || 0} verified`}
            icon={Users}
            isLoading={isLoadingSummary}
          />
          <StatCard
            title="Active Votes"
            value={summary?.activeVotes}
            description="Awaiting decisions"
            icon={Vote}
            isLoading={isLoadingSummary}
          />
          <StatCard
            title="Pending Suggestions"
            value={summary?.pendingSuggestions}
            description="Needs executive review"
            icon={MessageSquare}
            isLoading={isLoadingSummary}
          />
          <StatCard
            title="Total Funding"
            value={summary?.totalFunding ? `KES ${summary.totalFunding.toLocaleString()}` : undefined}
            description="Distributed to youth"
            icon={TrendingUp}
            isLoading={isLoadingSummary}
          />
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <Card className="col-span-4">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest updates across all civic departments.</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingActivity ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : activity?.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center text-muted-foreground">
                  <AlertCircle className="h-8 w-8 mb-2 opacity-20" />
                  <p>No recent activity found.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {activity?.map((item) => (
                    <div key={item.id} className="flex items-center gap-4">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary">
                        {getActivityIcon(item.type)}
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">{item.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(item.timestamp).toLocaleString()}
                        </p>
                      </div>
                      {item.status && (
                        <Badge variant="outline" className="capitalize">
                          {item.status.replace("_", " ")}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="col-span-3">
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
              <CardDescription>Other platform metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Upcoming Events</span>
                </div>
                <span className="font-bold">{isLoadingSummary ? <Skeleton className="h-4 w-8" /> : summary?.upcomingEvents || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Registered Talents</span>
                </div>
                <span className="font-bold">{isLoadingSummary ? <Skeleton className="h-4 w-8" /> : summary?.totalTalents || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Published Reports</span>
                </div>
                <span className="font-bold">{isLoadingSummary ? <Skeleton className="h-4 w-8" /> : summary?.recentReports || 0}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

function StatCard({ 
  title, 
  value, 
  description, 
  icon: Icon,
  isLoading 
}: { 
  title: string; 
  value?: string | number; 
  description: string; 
  icon: any;
  isLoading: boolean;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-8 w-20 mb-1" />
        ) : (
          <div className="text-2xl font-bold">{value || 0}</div>
        )}
        <p className="text-xs text-muted-foreground mt-1">{description}</p>
      </CardContent>
    </Card>
  );
}

function getActivityIcon(type: string) {
  switch (type) {
    case 'member': return <Users className="h-4 w-4" />;
    case 'funding': return <TrendingUp className="h-4 w-4" />;
    case 'suggestion': return <MessageSquare className="h-4 w-4" />;
    case 'vote': return <Vote className="h-4 w-4" />;
    case 'report': return <FileText className="h-4 w-4" />;
    case 'event': return <Calendar className="h-4 w-4" />;
    case 'talent': return <Star className="h-4 w-4" />;
    default: return <AlertCircle className="h-4 w-4" />;
  }
}
