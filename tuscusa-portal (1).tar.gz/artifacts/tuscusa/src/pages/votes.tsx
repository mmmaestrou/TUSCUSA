import { useListVotes, useCastVote } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Vote as VoteIcon, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function Votes() {
  const { data: votes, isLoading } = useListVotes();
  const castVote = useCastVote();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // In a real app, this would come from auth context
  const voterId = "user_" + Math.random().toString(36).substring(2, 9);
  const [votingOn, setVotingOn] = useState<number | null>(null);

  const handleVote = (voteId: number, choice: "yes" | "no" | "abstain") => {
    setVotingOn(voteId);
    castVote.mutate({
      data: {
        voterId,
        choice
      }
    }, {
      onSuccess: () => {
        toast({ title: "Vote recorded", description: "Your voice has been heard." });
        queryClient.invalidateQueries({ queryKey: ["/api/votes"] });
        setVotingOn(null);
      },
      onError: () => {
        toast({ title: "Error casting vote", description: "You may have already voted on this issue.", variant: "destructive" });
        setVotingOn(null);
      }
    });
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Policy Votes</h1>
          <p className="text-muted-foreground">Direct democracy in action. Have your say on ward policies and decisions.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {isLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i} className="flex flex-col">
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/4" />
                </CardHeader>
                <CardContent className="flex-1">
                  <Skeleton className="h-16 w-full mb-6" />
                  <div className="space-y-3">
                    <Skeleton className="h-2 w-full" />
                    <Skeleton className="h-2 w-full" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : votes?.length === 0 ? (
            <div className="col-span-full py-16 flex flex-col items-center justify-center text-center border rounded-xl border-dashed bg-card/50">
              <VoteIcon className="h-12 w-12 text-muted-foreground opacity-20 mb-4" />
              <h3 className="text-xl font-medium">No active votes</h3>
              <p className="text-muted-foreground max-w-sm mt-2">There are currently no open polls or policies requiring a vote.</p>
            </div>
          ) : (
            votes?.map((vote) => {
              const isOpen = vote.status === "open";
              const totalVoters = vote.totalVoters || 1; // Prevent division by zero
              const yesPercent = Math.round((vote.yesCount / totalVoters) * 100) || 0;
              const noPercent = Math.round((vote.noCount / totalVoters) * 100) || 0;
              const abstainPercent = Math.round((vote.abstainCount / totalVoters) * 100) || 0;
              
              return (
                <Card key={vote.id} className={`flex flex-col ${isOpen ? 'border-primary/30 shadow-md' : 'opacity-80'}`}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start mb-2">
                      {isOpen ? (
                        <Badge className="bg-primary hover:bg-primary/90"><Clock className="h-3 w-3 mr-1" /> Open</Badge>
                      ) : (
                        <Badge variant="secondary"><CheckCircle2 className="h-3 w-3 mr-1" /> Closed</Badge>
                      )}
                      <span className="text-xs text-muted-foreground">
                        Ends: {new Date(vote.endDate).toLocaleDateString()}
                      </span>
                    </div>
                    <CardTitle className="text-xl">{vote.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-muted-foreground mb-6 line-clamp-3">
                      {vote.description}
                    </p>
                    
                    <div className="space-y-4">
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-green-600">Yes ({vote.yesCount})</span>
                          <span className="text-muted-foreground">{yesPercent}%</span>
                        </div>
                        <Progress value={yesPercent} className="h-2 bg-muted" indicatorClassName="bg-green-500" />
                      </div>
                      
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-destructive">No ({vote.noCount})</span>
                          <span className="text-muted-foreground">{noPercent}%</span>
                        </div>
                        <Progress value={noPercent} className="h-2 bg-muted" indicatorClassName="bg-destructive" />
                      </div>
                      
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-muted-foreground">Abstain ({vote.abstainCount})</span>
                          <span className="text-muted-foreground">{abstainPercent}%</span>
                        </div>
                        <Progress value={abstainPercent} className="h-2" indicatorClassName="bg-slate-400" />
                      </div>
                    </div>
                  </CardContent>
                  
                  {isOpen && (
                    <CardFooter className="pt-4 border-t bg-muted/10 grid grid-cols-3 gap-2">
                      <Button 
                        variant="outline" 
                        className="bg-green-50 hover:bg-green-100 hover:text-green-700 border-green-200 text-green-700 dark:bg-green-950 dark:hover:bg-green-900"
                        onClick={() => handleVote(vote.id, "yes")}
                        disabled={votingOn === vote.id}
                      >
                        Yes
                      </Button>
                      <Button 
                        variant="outline" 
                        className="bg-red-50 hover:bg-red-100 hover:text-red-700 border-red-200 text-red-700 dark:bg-red-950 dark:hover:bg-red-900"
                        onClick={() => handleVote(vote.id, "no")}
                        disabled={votingOn === vote.id}
                      >
                        No
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => handleVote(vote.id, "abstain")}
                        disabled={votingOn === vote.id}
                      >
                        Abstain
                      </Button>
                    </CardFooter>
                  )}
                  
                  {!isOpen && (
                    <CardFooter className="pt-4 border-t bg-muted/30 flex justify-center">
                      <p className="text-sm font-medium">
                        Final Result: {" "}
                        {vote.yesCount > vote.noCount ? (
                          <span className="text-green-600 font-bold">Passed</span>
                        ) : vote.noCount > vote.yesCount ? (
                          <span className="text-destructive font-bold">Rejected</span>
                        ) : (
                          <span className="text-muted-foreground font-bold">Tied</span>
                        )}
                      </p>
                    </CardFooter>
                  )}
                </Card>
              );
            })
          )}
        </div>
      </div>
    </Layout>
  );
}