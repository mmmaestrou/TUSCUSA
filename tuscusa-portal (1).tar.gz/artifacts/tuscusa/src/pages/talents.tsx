import { useListTalents } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search, Star, MapPin, Award, Mail, Users, User } from "lucide-react";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Talents() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  const { data: talents, isLoading } = useListTalents();

  const filteredTalents = talents?.filter(t => {
    const matchesSearch = 
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      t.skill.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.ward && t.ward.toLowerCase().includes(searchTerm.toLowerCase()));
      
    if (activeTab === "all") return matchesSearch;
    return matchesSearch && t.type === activeTab;
  });

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Talent Showcase</h1>
            <p className="text-muted-foreground">Discover the brilliant minds, artists, and clubs in our ward.</p>
          </div>
        </div>

        <Card className="bg-card shadow-sm border-primary/20">
          <div className="p-2 sm:p-4 flex flex-col sm:flex-row gap-4 items-center">
            <div className="relative w-full sm:max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by name, skill, or ward..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-background"
              />
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="individual">Individuals</TabsTrigger>
                <TabsTrigger value="club">Clubs & Groups</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </Card>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="flex flex-col h-full">
                <CardHeader className="pb-3 flex flex-row items-center gap-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </CardHeader>
                <CardContent className="flex-1 space-y-4">
                  <Skeleton className="h-16 w-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredTalents?.length === 0 ? (
            <div className="col-span-full py-16 flex flex-col items-center justify-center text-center border rounded-xl border-dashed bg-card/50">
              <Star className="h-12 w-12 text-muted-foreground opacity-20 mb-4" />
              <h3 className="text-xl font-medium">No talents found</h3>
              <p className="text-muted-foreground mt-1">Try adjusting your search criteria.</p>
            </div>
          ) : (
            filteredTalents?.map((talent) => (
              <Card key={talent.id} className="flex flex-col h-full hover-elevate transition-all overflow-hidden">
                <div className="h-2 bg-gradient-to-r from-primary to-amber-500"></div>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 border border-primary/20">
                        {talent.type === 'club' ? <Users className="h-6 w-6" /> : <User className="h-6 w-6" />}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{talent.name}</CardTitle>
                        <div className="flex items-center gap-1.5 mt-1 text-sm text-primary font-medium">
                          <Star className="h-3 w-3 fill-primary" />
                          {talent.skill}
                        </div>
                      </div>
                    </div>
                    <Badge variant={talent.type === 'club' ? 'default' : 'secondary'} className="capitalize">
                      {talent.type}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <p className="text-muted-foreground text-sm line-clamp-3 mb-4 flex-1">
                    {talent.description}
                  </p>
                  
                  <div className="space-y-2 text-sm text-muted-foreground bg-muted/20 p-3 rounded-md border">
                    {talent.ward && (
                      <div className="flex items-start gap-2">
                        <MapPin className="h-4 w-4 shrink-0 mt-0.5" />
                        <span>{talent.ward}</span>
                      </div>
                    )}
                    {talent.achievements && (
                      <div className="flex items-start gap-2">
                        <Award className="h-4 w-4 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{talent.achievements}</span>
                      </div>
                    )}
                    {talent.contactInfo && (
                      <div className="flex items-start gap-2">
                        <Mail className="h-4 w-4 shrink-0 mt-0.5" />
                        <span className="truncate">{talent.contactInfo}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}