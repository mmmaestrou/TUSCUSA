import { Link } from "wouter";
import { ArrowRight, BarChart3, Users, Vote, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useGetDashboardSummary } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: summary, isLoading } = useGetDashboardSummary();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="px-6 py-4 flex items-center justify-between border-b bg-card z-10 sticky top-0">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-bold">
            T
          </div>
          <span className="text-xl font-bold tracking-tight text-foreground">TUSCUSA</span>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/dashboard" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            Portal
          </Link>
          <Button asChild>
            <Link href="/dashboard">Enter Command Centre</Link>
          </Button>
        </nav>
      </header>

      <main className="flex-1">
        <section className="py-20 md:py-32 px-6 max-w-6xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-foreground mb-6">
            Radical Transparency. <br/> <span className="text-primary">Civic Power.</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-10 leading-relaxed">
            The ward-level command centre for youth empowerment. Every shilling tracked, every voice heard, every vote counted.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="h-14 px-8 text-lg w-full sm:w-auto" asChild>
              <Link href="/dashboard">
                Access Portal <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="py-12 bg-muted/30 border-y">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div className="space-y-2">
                <h4 className="text-4xl font-bold text-foreground">
                  {isLoading ? <Skeleton className="h-10 w-24 mx-auto" /> : summary?.totalMembers || 0}
                </h4>
                <p className="text-sm font-medium text-muted-foreground">Registered Youth</p>
              </div>
              <div className="space-y-2">
                <h4 className="text-4xl font-bold text-foreground">
                  {isLoading ? <Skeleton className="h-10 w-24 mx-auto" /> : summary?.activeVotes || 0}
                </h4>
                <p className="text-sm font-medium text-muted-foreground">Active Policy Votes</p>
              </div>
              <div className="space-y-2">
                <h4 className="text-4xl font-bold text-foreground">
                  {isLoading ? <Skeleton className="h-10 w-24 mx-auto" /> : (summary?.totalFunding ? `KES ${(summary.totalFunding / 1000).toFixed(1)}k` : "KES 0")}
                </h4>
                <p className="text-sm font-medium text-muted-foreground">Funds Tracked</p>
              </div>
              <div className="space-y-2">
                <h4 className="text-4xl font-bold text-foreground">
                  {isLoading ? <Skeleton className="h-10 w-24 mx-auto" /> : summary?.recentReports || 0}
                </h4>
                <p className="text-sm font-medium text-muted-foreground">Official Reports</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-card">
          <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-8">
            <div className="bg-background p-8 rounded-xl border hover-elevate transition-all duration-300">
              <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-6">
                <BarChart3 className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Funding Accountability</h3>
              <p className="text-muted-foreground mb-4">Track government youth funds in real-time. See exactly who received what and for what purpose.</p>
              <Link href="/funding" className="text-primary text-sm font-medium hover:underline inline-flex items-center">
                View Tracker <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
            
            <div className="bg-background p-8 rounded-xl border hover-elevate transition-all duration-300">
              <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-6">
                <Vote className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Direct Democracy</h3>
              <p className="text-muted-foreground mb-4">Cast your vote on ward policies and initiatives. Instant, transparent polling results.</p>
              <Link href="/votes" className="text-primary text-sm font-medium hover:underline inline-flex items-center">
                View Polls <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
            
            <div className="bg-background p-8 rounded-xl border hover-elevate transition-all duration-300">
              <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-6">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Member Directory</h3>
              <p className="text-muted-foreground mb-4">A verified database of youth members, skills, and talents across all sub-locations.</p>
              <Link href="/members" className="text-primary text-sm font-medium hover:underline inline-flex items-center">
                Search Database <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-sidebar text-sidebar-foreground py-12 border-t border-sidebar-border">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-bold">
              T
            </div>
            <span className="text-xl font-bold tracking-tight">TUSCUSA</span>
          </div>
          <p className="text-sm text-sidebar-foreground/70 text-center md:text-left">
            Empowering youth through radical transparency and civic action.
          </p>
          <div className="flex gap-4">
            <Link href="/dashboard" className="text-sm hover:text-primary transition-colors">Portal</Link>
            <Link href="/admin" className="text-sm hover:text-primary transition-colors">Admin</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}