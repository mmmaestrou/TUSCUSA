import { useListEvents } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, ExternalLink, Briefcase, GraduationCap, Banknote, Star } from "lucide-react";

export default function Events() {
  const { data: events, isLoading } = useListEvents();

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case "job": return <Briefcase className="h-4 w-4" />;
      case "training": return <GraduationCap className="h-4 w-4" />;
      case "funding_call": return <Banknote className="h-4 w-4" />;
      case "talent_showcase": return <Star className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  const getEventTypeLabel = (type: string) => {
    return type.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "job": return "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800";
      case "training": return "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800";
      case "funding_call": return "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-800";
      case "talent_showcase": return "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800";
      default: return "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700";
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Events & Opportunities</h1>
          <p className="text-muted-foreground">Discover jobs, training programs, and community gatherings.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="flex flex-col h-full">
                <CardHeader className="pb-3">
                  <Skeleton className="h-5 w-24 mb-2" />
                  <Skeleton className="h-6 w-full" />
                </CardHeader>
                <CardContent className="flex-1 space-y-4">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                  
                  <div className="space-y-2 mt-4">
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Skeleton className="h-10 w-full" />
                </CardFooter>
              </Card>
            ))
          ) : events?.length === 0 ? (
            <div className="col-span-full py-16 flex flex-col items-center justify-center text-center border rounded-xl border-dashed bg-card/50">
              <Calendar className="h-12 w-12 text-muted-foreground opacity-20 mb-4" />
              <h3 className="text-xl font-medium">No upcoming events</h3>
              <p className="text-muted-foreground mt-1">Check back later for new opportunities.</p>
            </div>
          ) : (
            events?.map((event) => (
              <Card key={event.id} className={`flex flex-col h-full ${!event.isActive ? 'opacity-60' : ''}`}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline" className={`flex items-center gap-1.5 ${getEventTypeColor(event.type)}`}>
                      {getEventTypeIcon(event.type)}
                      {getEventTypeLabel(event.type)}
                    </Badge>
                    {!event.isActive && (
                      <Badge variant="secondary">Closed</Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl leading-tight">{event.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <p className="text-muted-foreground text-sm line-clamp-3 mb-6 flex-1">
                    {event.description}
                  </p>
                  
                  <div className="space-y-2.5 bg-muted/30 p-3 rounded-lg border mt-auto text-sm">
                    {event.eventDate && (
                      <div className="flex items-start gap-2 text-foreground">
                        <Calendar className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <span><strong>Date:</strong> {new Date(event.eventDate).toLocaleDateString()}</span>
                      </div>
                    )}
                    {event.deadline && (
                      <div className="flex items-start gap-2 text-foreground">
                        <Calendar className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                        <span><strong>Deadline:</strong> {new Date(event.deadline).toLocaleDateString()}</span>
                      </div>
                    )}
                    {event.location && (
                      <div className="flex items-start gap-2 text-foreground">
                        <MapPin className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <span>{event.location}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="pt-4 border-t">
                  {event.applicationLink ? (
                    <Button className="w-full" asChild disabled={!event.isActive}>
                      <a href={event.applicationLink} target="_blank" rel="noopener noreferrer">
                        {event.type === 'job' || event.type === 'funding_call' || event.type === 'training' 
                          ? 'Apply Now' 
                          : 'Register / View Details'}
                        <ExternalLink className="h-4 w-4 ml-2" />
                      </a>
                    </Button>
                  ) : (
                    <Button variant="secondary" className="w-full" disabled>
                      No Link Available
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}