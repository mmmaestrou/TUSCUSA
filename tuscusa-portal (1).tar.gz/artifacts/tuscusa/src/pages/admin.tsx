import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import { Layout } from "@/components/layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Database, Vote, FileText, Calendar, MessageSquare, Plus, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

import {
  useListMembers, useUpdateMember, useCreateMember,
  useListFunding, useCreateFunding, useUpdateFunding,
  useListSuggestions, useUpdateSuggestion,
  useListVotes, useCreateVote,
  useCreateReport,
  useCreateEvent
} from "@workspace/api-client-react";

export default function AdminPanel() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-destructive">Executive Admin Panel</h1>
          <p className="text-muted-foreground">Restricted access area for TUSCUSA executives.</p>
        </div>

        <Tabs defaultValue="members" className="w-full">
          <TabsList className="w-full justify-start overflow-x-auto flex-nowrap mb-6 bg-muted/50 p-1 border h-auto">
            <TabsTrigger value="members" className="flex items-center gap-2 py-2"><Database className="h-4 w-4"/> Members</TabsTrigger>
            <TabsTrigger value="funding" className="flex items-center gap-2 py-2"><ShieldCheck className="h-4 w-4"/> Funding</TabsTrigger>
            <TabsTrigger value="suggestions" className="flex items-center gap-2 py-2"><MessageSquare className="h-4 w-4"/> Suggestions</TabsTrigger>
            <TabsTrigger value="votes" className="flex items-center gap-2 py-2"><Vote className="h-4 w-4"/> Votes</TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2 py-2"><FileText className="h-4 w-4"/> Reports</TabsTrigger>
            <TabsTrigger value="events" className="flex items-center gap-2 py-2"><Calendar className="h-4 w-4"/> Events</TabsTrigger>
          </TabsList>
          
          <TabsContent value="members">
            <MembersAdminTab />
          </TabsContent>

          <TabsContent value="funding">
            <FundingAdminTab />
          </TabsContent>
          
          <TabsContent value="suggestions">
            <SuggestionsAdminTab />
          </TabsContent>
          
          <TabsContent value="votes">
            <VotesAdminTab />
          </TabsContent>
          
          <TabsContent value="reports">
            <ReportsAdminTab />
          </TabsContent>
          
          <TabsContent value="events">
            <EventsAdminTab />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

function MembersAdminTab() {
  const { data: members, isLoading } = useListMembers();
  const updateMember = useUpdateMember();
  const createMember = useCreateMember();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [fullName, setFullName] = useState("");
  const [idNumber, setIdNumber] = useState("");
  const [phone, setPhone] = useState("");
  const [ward, setWard] = useState("");
  const [employmentStatus, setEmploymentStatus] = useState<"student" | "employed" | "unemployed" | "self_employed">("student");

  const handleVerify = (id: number) => {
    updateMember.mutate({
      id,
      data: { isVerified: true }
    }, {
      onSuccess: () => {
        toast({ title: "Member Verified", description: "The member has been verified." });
        queryClient.invalidateQueries({ queryKey: ["/api/members"] });
      }
    });
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    createMember.mutate({
      data: {
        fullName,
        idNumber,
        phone,
        ward,
        employmentStatus
      }
    }, {
      onSuccess: () => {
        toast({ title: "Member Added", description: "New member successfully registered." });
        queryClient.invalidateQueries({ queryKey: ["/api/members"] });
        setShowAddForm(false);
        setFullName("");
        setIdNumber("");
        setPhone("");
        setWard("");
      }
    });
  };

  const pendingMembers = members?.filter(m => !m.isVerified) || [];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row justify-between items-start">
          <div>
            <CardTitle>Member Database</CardTitle>
            <CardDescription>Manually add members to the system.</CardDescription>
          </div>
          <Button onClick={() => setShowAddForm(!showAddForm)}>
            {showAddForm ? "Cancel" : <><Plus className="h-4 w-4 mr-2" /> Add Member</>}
          </Button>
        </CardHeader>
        <CardContent>
          {showAddForm ? (
            <form onSubmit={handleAddMember} className="space-y-4 border p-4 rounded-lg bg-muted/10">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input id="fullName" value={fullName} onChange={e => setFullName(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="idNumber">ID Number</Label>
                  <Input id="idNumber" value={idNumber} onChange={e => setIdNumber(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" value={phone} onChange={e => setPhone(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ward">Ward</Label>
                  <Input id="ward" value={ward} onChange={e => setWard(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="employmentStatus">Employment Status</Label>
                  <Select value={employmentStatus} onValueChange={(v: any) => setEmploymentStatus(v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="employed">Employed</SelectItem>
                      <SelectItem value="self_employed">Self Employed</SelectItem>
                      <SelectItem value="unemployed">Unemployed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button type="submit" disabled={createMember.isPending}>Register Member</Button>
            </form>
          ) : (
            <div className="py-8 text-center text-muted-foreground border border-dashed rounded-lg bg-muted/20">
              Click "Add Member" to manually register a youth member.
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Member Verification</CardTitle>
          <CardDescription>Verify new member registrations.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-32 w-full" />
          ) : pendingMembers.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground border border-dashed rounded-lg bg-muted/20">
              No pending verifications.
            </div>
          ) : (
            <div className="space-y-4">
              {pendingMembers.map(member => (
                <div key={member.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">{member.fullName}</p>
                    <p className="text-sm text-muted-foreground">{member.ward} • {member.idNumber} • {member.phone}</p>
                  </div>
                  <Button size="sm" className="mt-4 sm:mt-0" onClick={() => handleVerify(member.id)} disabled={updateMember.isPending}>
                    <CheckCircle2 className="h-4 w-4 mr-2" /> Verify Member
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function FundingAdminTab() {
  const [showForm, setShowForm] = useState(false);
  const createFunding = useCreateFunding();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [applicantName, setApplicantName] = useState("");
  const [fundProgram, setFundProgram] = useState("");
  const [amountApplied, setAmountApplied] = useState("");
  const [purpose, setPurpose] = useState<"business" | "education" | "training" | "other">("business");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createFunding.mutate({
      data: {
        applicantName,
        fundProgram,
        amountApplied: Number(amountApplied),
        purpose,
        status: "pending",
        isAnonymous: false
      }
    }, {
      onSuccess: () => {
        toast({ title: "Funding Record Created" });
        queryClient.invalidateQueries({ queryKey: ["/api/funding"] });
        setShowForm(false);
        setApplicantName("");
        setFundProgram("");
        setAmountApplied("");
      }
    });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row justify-between items-start">
        <div>
          <CardTitle>Funding Management</CardTitle>
          <CardDescription>Add new funding disbursements.</CardDescription>
        </div>
        <Button onClick={() => setShowForm(!showForm)}>
          {showForm ? "Cancel" : <><Plus className="h-4 w-4 mr-2" /> Add Record</>}
        </Button>
      </CardHeader>
      <CardContent>
        {showForm ? (
          <form onSubmit={handleSubmit} className="space-y-4 border p-4 rounded-lg bg-muted/10">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="applicantName">Applicant Name</Label>
                <Input id="applicantName" value={applicantName} onChange={e => setApplicantName(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fundProgram">Fund Program</Label>
                <Input id="fundProgram" value={fundProgram} onChange={e => setFundProgram(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="amountApplied">Amount Applied (KES)</Label>
                <Input id="amountApplied" type="number" value={amountApplied} onChange={e => setAmountApplied(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="purpose">Purpose</Label>
                <Select value={purpose} onValueChange={(v: any) => setPurpose(v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="training">Training</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button type="submit" disabled={createFunding.isPending}>Save Record</Button>
          </form>
        ) : (
          <div className="py-8 text-center text-muted-foreground border border-dashed rounded-lg bg-muted/20">
            Click "Add Record" to create a new funding entry.
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function SuggestionsAdminTab() {
  const { data: suggestions, isLoading } = useListSuggestions();
  const updateSuggestion = useUpdateSuggestion();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [responseTexts, setResponseTexts] = useState<Record<number, string>>({});
  const [statusValues, setStatusValues] = useState<Record<number, string>>({});

  const handleRespond = (id: number) => {
    updateSuggestion.mutate({
      id,
      data: {
        executiveResponse: responseTexts[id],
        status: statusValues[id] || "under_review"
      }
    }, {
      onSuccess: () => {
        toast({ title: "Response Submitted" });
        queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      }
    });
  };

  const pendingSuggestions = suggestions?.filter(s => s.status === "pending" || s.status === "under_review") || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Suggestions</CardTitle>
        <CardDescription>Respond to community feedback.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-32 w-full" />
        ) : pendingSuggestions.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground border border-dashed rounded-lg bg-muted/20">
            No pending suggestions.
          </div>
        ) : (
          <div className="space-y-4">
            {pendingSuggestions.map(s => (
              <div key={s.id} className="p-4 border rounded-lg space-y-4">
                <div>
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium text-lg">{s.title}</h4>
                    <Badge variant="secondary">{s.status}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{s.content}</p>
                </div>
                <div className="space-y-2">
                  <Label>Status Update</Label>
                  <Select 
                    value={statusValues[s.id] || s.status} 
                    onValueChange={(v) => setStatusValues({...statusValues, [s.id]: v})}
                  >
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="under_review">Under Review</SelectItem>
                      <SelectItem value="accepted">Accepted</SelectItem>
                      <SelectItem value="implemented">Implemented</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Executive Response</Label>
                  <Textarea 
                    value={responseTexts[s.id] || s.executiveResponse || ""}
                    onChange={e => setResponseTexts({...responseTexts, [s.id]: e.target.value})}
                    placeholder="Enter your official response..."
                  />
                </div>
                <Button onClick={() => handleRespond(s.id)} disabled={updateSuggestion.isPending}>
                  Update & Respond
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function VotesAdminTab() {
  const createVote = useCreateVote();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [endDate, setEndDate] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createVote.mutate({
      data: {
        title,
        description,
        startDate: new Date().toISOString(),
        endDate: new Date(endDate).toISOString()
      }
    }, {
      onSuccess: () => {
        toast({ title: "Vote Created" });
        queryClient.invalidateQueries({ queryKey: ["/api/votes"] });
        setTitle("");
        setDescription("");
        setEndDate("");
      }
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Policy Vote</CardTitle>
        <CardDescription>Initiate a new policy vote for the community.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4 max-w-2xl">
          <div className="space-y-2">
            <Label htmlFor="voteTitle">Title</Label>
            <Input id="voteTitle" value={title} onChange={e => setTitle(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="voteDesc">Description</Label>
            <Textarea id="voteDesc" value={description} onChange={e => setDescription(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="voteEnd">End Date</Label>
            <Input id="voteEnd" type="date" value={endDate} onChange={e => setEndDate(e.target.value)} required />
          </div>
          <Button type="submit" disabled={createVote.isPending}>Launch Vote</Button>
        </form>
      </CardContent>
    </Card>
  );
}

function ReportsAdminTab() {
  const createReport = useCreateReport();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [title, setTitle] = useState("");
  const [type, setType] = useState<"financial" | "minutes" | "decision" | "other">("minutes");
  const [content, setContent] = useState("");
  const [period, setPeriod] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createReport.mutate({
      data: {
        title,
        type,
        content,
        period: period || undefined,
        publishedBy: "Admin Executive"
      }
    }, {
      onSuccess: () => {
        toast({ title: "Report Published" });
        queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
        setTitle("");
        setContent("");
        setPeriod("");
      }
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Publish Official Report</CardTitle>
        <CardDescription>Upload meeting minutes, financial reports, or decisions.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4 max-w-3xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="reportTitle">Report Title</Label>
              <Input id="reportTitle" value={title} onChange={e => setTitle(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reportType">Type</Label>
              <Select value={type} onValueChange={(v: any) => setType(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="minutes">Meeting Minutes</SelectItem>
                  <SelectItem value="financial">Financial</SelectItem>
                  <SelectItem value="decision">Decision</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="reportPeriod">Period (Optional)</Label>
              <Input id="reportPeriod" placeholder="e.g. Q3 2023" value={period} onChange={e => setPeriod(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="reportContent">Content</Label>
            <Textarea id="reportContent" className="min-h-[200px]" value={content} onChange={e => setContent(e.target.value)} required />
          </div>
          <Button type="submit" disabled={createReport.isPending}>Publish Report</Button>
        </form>
      </CardContent>
    </Card>
  );
}

function EventsAdminTab() {
  const createEvent = useCreateEvent();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<"event" | "job" | "training" | "funding_call" | "talent_showcase" | "other">("event");
  const [eventDate, setEventDate] = useState("");
  const [deadline, setDeadline] = useState("");
  const [location, setLocation] = useState("");
  const [applicationLink, setApplicationLink] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createEvent.mutate({
      data: {
        title,
        description,
        type,
        eventDate: eventDate ? new Date(eventDate).toISOString() : undefined,
        deadline: deadline ? new Date(deadline).toISOString() : undefined,
        location,
        applicationLink
      }
    }, {
      onSuccess: () => {
        toast({ title: "Event Created" });
        queryClient.invalidateQueries({ queryKey: ["/api/events"] });
        setTitle("");
        setDescription("");
        setEventDate("");
        setDeadline("");
        setLocation("");
        setApplicationLink("");
      }
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Event / Opportunity</CardTitle>
        <CardDescription>Announce a new event, job, or training program.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4 max-w-3xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="eventTitle">Title</Label>
              <Input id="eventTitle" value={title} onChange={e => setTitle(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="eventType">Type</Label>
              <Select value={type} onValueChange={(v: any) => setType(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="event">Event</SelectItem>
                  <SelectItem value="job">Job</SelectItem>
                  <SelectItem value="training">Training</SelectItem>
                  <SelectItem value="funding_call">Funding Call</SelectItem>
                  <SelectItem value="talent_showcase">Talent Showcase</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="eventDate">Event Date</Label>
              <Input id="eventDate" type="date" value={eventDate} onChange={e => setEventDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="deadline">Deadline</Label>
              <Input id="deadline" type="date" value={deadline} onChange={e => setDeadline(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input id="location" value={location} onChange={e => setLocation(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="applicationLink">Application Link</Label>
              <Input id="applicationLink" type="url" value={applicationLink} onChange={e => setApplicationLink(e.target.value)} placeholder="https://" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="eventDesc">Description</Label>
            <Textarea id="eventDesc" value={description} onChange={e => setDescription(e.target.value)} required />
          </div>
          <Button type="submit" disabled={createEvent.isPending}>Create Opportunity</Button>
        </form>
      </CardContent>
    </Card>
  );
}