import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const fundingTable = pgTable("funding", {
  id: serial("id").primaryKey(),
  applicantName: text("applicant_name").notNull(),
  isAnonymous: boolean("is_anonymous").notNull().default(false),
  fundProgram: text("fund_program").notNull(),
  amountApplied: integer("amount_applied").notNull(),
  amountReceived: integer("amount_received"),
  purpose: text("purpose").notNull().default("other"),
  status: text("status").notNull().default("pending"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertFundingSchema = createInsertSchema(fundingTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertFunding = z.infer<typeof insertFundingSchema>;
export type Funding = typeof fundingTable.$inferSelect;
