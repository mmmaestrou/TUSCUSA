import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const talentsTable = pgTable("talents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("individual"),
  skill: text("skill").notNull(),
  description: text("description").notNull(),
  ward: text("ward"),
  contactInfo: text("contact_info"),
  achievements: text("achievements"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTalentSchema = createInsertSchema(talentsTable).omit({ id: true, createdAt: true });
export type InsertTalent = z.infer<typeof insertTalentSchema>;
export type Talent = typeof talentsTable.$inferSelect;
